package com.hussein.startup

class Note{

    var nodeID:Int?=null
    var nodeName:String?=null
    var nodeDes:String?=null

    constructor(nodeID:Int,nodeName:String,nodeDes:String){
        this.nodeID=nodeID
        this.nodeName=nodeName
        this.nodeDes=nodeDes
    }

}
