



fun showInfo(cardID:Int){
    // check if card is valid
    print("CardLD: $cardID")
}


fun  showInfo(name:String){
    // check if user is active
    print("Name: $name")
}




fun  main(){

    showInfo("Hussein Alrubaye")
    showInfo(7264374)
}