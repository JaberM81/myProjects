
/*

>
<
>=
<=
==
!=

And Gate (&&)
    True && True =True
    True && False =False
    False && True =False
    False && False =False

OR Gate(||)
    True && True =True
    True && False =True
    False && True =True
    False && False =False

NOT gate (!)
 True =False
 False = True
 */



fun main(){

    val age= 17

    println( age in 20..30)
}
